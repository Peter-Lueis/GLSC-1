
@extends('master')

@section('judul_halaman', 'Halaman Home')


@section('konten')

	<p>Ini Adalah Halaman Home</p>
	<p>Selamat datang !</p>

@endsection

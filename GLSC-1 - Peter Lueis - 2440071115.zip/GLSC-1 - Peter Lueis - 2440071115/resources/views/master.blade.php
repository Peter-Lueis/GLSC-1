<!DOCTYPE html>
<html>
<head>
	<title>GLSC-1</title>
</head>
<body>

	<header>

		<h2>GLSC-1 Web Programming</h2>
		<nav>
			<a href="/blog">HOME</a>
			|
			<a href="/blog/tentang">TENTANG</a>
		</nav>
	</header>
	<hr/>
	<br/>
	<br/>

	<h3> @yield('judul_halaman') </h3>


	@yield('konten')


	<br/>
	<br/>
	<hr/>

</body>
</html>

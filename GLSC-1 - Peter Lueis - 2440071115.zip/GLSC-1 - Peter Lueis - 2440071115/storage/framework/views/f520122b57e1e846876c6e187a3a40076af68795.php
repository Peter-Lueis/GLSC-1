<!DOCTYPE html>
<html>
<head>
	<title>GLSC-1</title>
</head>
<body>

	<header>

		<h2>GLSC-1 Web Programming</h2>
		<nav>
			<a href="/blog">HOME</a>
			|
			<a href="/blog/tentang">TENTANG</a>
		</nav>
	</header>
	<hr/>
	<br/>
	<br/>

	<h3> <?php echo $__env->yieldContent('judul_halaman'); ?> </h3>


	<?php echo $__env->yieldContent('konten'); ?>


	<br/>
	<br/>
	<hr/>

</body>
</html>
<?php /**PATH C:\semester 5\Web Prog\GLSC-1\resources\views/master.blade.php ENDPATH**/ ?>